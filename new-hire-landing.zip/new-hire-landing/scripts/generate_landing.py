#!/usr/bin/env python3
"""
new-hire-landing skill — 核心生成脚本
用法：python3 generate_landing.py <花名册文件> [--output <输出路径>] [--dept <部门名称>] [--review-months <N>] [--password <密码>] [--reviewer <评委1,评委2,...>]

支持的花名册格式：xlsx / xls / csv
必须包含列（列名模糊匹配）：薯名/姓名、入职日期、部门/小组、直接上级/L1、在职状态
可选列：年龄、前公司/上家公司、学历、学校、真实姓名
"""
import sys
import re
import json
import argparse
from datetime import date, datetime, timedelta
from pathlib import Path

def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("roster", help="花名册文件路径（xlsx/xls/csv）")
    p.add_argument("--output", default="new_hire_landing.html", help="输出 HTML 路径")
    p.add_argument("--dept", default="", help="部门/团队名称（用于标题）")
    p.add_argument("--review-months", type=float, default=5.5, help="述职资格：入职满N个月（默认5.5）")
    p.add_argument("--trial-months", type=float, default=6.0, help="试用期时长（月，默认6）")
    p.add_argument("--since", default="", help="新人统计起始入职日期，格式YYYY-MM-DD（默认6个月前）")
    p.add_argument("--password", default="", help="看板访问密码（留空不设密码）")
    p.add_argument("--reviewer", default="", help="固定评委薯名，逗号分隔（如：又思,金槌）")
    return p.parse_args()

def fuzzy_col(df, candidates):
    """模糊匹配列名"""
    cols = df.columns.tolist()
    for c in candidates:
        for col in cols:
            if c in str(col) or str(col) in c:
                return col
    return None

def load_roster(path):
    """加载花名册，返回 DataFrame"""
    try:
        import pandas as pd
    except ImportError:
        print("需要安装 pandas 和 openpyxl：pip install pandas openpyxl xlrd")
        sys.exit(1)
    
    p = Path(path)
    suffix = p.suffix.lower()
    if suffix in ('.xlsx', '.xls'):
        df = pd.read_excel(path, dtype=str)
    elif suffix == '.csv':
        # 尝试不同编码
        for enc in ('utf-8-sig', 'gbk', 'utf-8'):
            try:
                df = pd.read_csv(path, dtype=str, encoding=enc)
                break
            except UnicodeDecodeError:
                continue
    else:
        print(f"不支持的文件格式：{suffix}")
        sys.exit(1)
    
    # 去掉全空行
    df = df.dropna(how='all')
    df.columns = [str(c).strip() for c in df.columns]
    return df

def extract_fields(df):
    """从 DataFrame 提取标准字段，返回 list[dict]"""
    col_name = fuzzy_col(df, ['薯名', '花名', '姓名', '名字'])
    col_join = fuzzy_col(df, ['入职日期', '入职时间', '入职', 'join'])
    col_dept = fuzzy_col(df, ['小组', '部门', '团队', 'team', 'dept'])
    col_lead = fuzzy_col(df, ['直接上级', 'L1', '上级', '汇报', '直属'])
    col_status = fuzzy_col(df, ['在职状态', '状态', '雇佣状态', 'status'])
    col_real = fuzzy_col(df, ['真实姓名', '姓名(真实)', '中文名', '法定姓名'])
    col_age = fuzzy_col(df, ['年龄', 'age'])
    col_prev = fuzzy_col(df, ['前公司', '上家公司', '上一家', '前雇主'])
    col_edu = fuzzy_col(df, ['学历', '最高学历', 'education'])
    col_school = fuzzy_col(df, ['学校', '毕业院校', '院校'])

    if not col_name or not col_join:
        print(f"❌ 找不到必要列。检测到的列名：{df.columns.tolist()}")
        print("  需要包含：薯名/姓名 + 入职日期")
        sys.exit(1)

    rows = []
    for _, r in df.iterrows():
        name = str(r[col_name]).strip() if col_name else ''
        join_str = str(r[col_join]).strip() if col_join else ''
        if not name or name in ('nan', 'None', ''):
            continue
        
        # 解析入职日期
        join_date = None
        for fmt in ('%Y/%m/%d', '%Y-%m-%d', '%Y.%m.%d', '%Y年%m月%d日'):
            try:
                join_date = datetime.strptime(join_str.split(' ')[0], fmt).date()
                break
            except:
                pass
        if not join_date:
            # pandas Timestamp
            try:
                ts = float(join_str)
                from datetime import date as d_
                import xlrd
                join_date = xlrd.xldate_as_datetime(ts, 0).date()
            except:
                pass
        if not join_date:
            continue
        
        status = str(r[col_status]).strip() if col_status else '在职'
        dept = str(r[col_dept]).strip() if col_dept else ''
        lead = str(r[col_lead]).strip() if col_lead else ''
        real = str(r[col_real]).strip() if col_real else ''
        age = str(r[col_age]).strip() if col_age else ''
        prev = str(r[col_prev]).strip() if col_prev else ''
        edu = str(r[col_edu]).strip() if col_edu else ''
        school = str(r[col_school]).strip() if col_school else ''
        
        for field in [dept, lead, real, age, prev, edu, school, status]:
            pass  # already stripped
        
        # 清理 nan
        for k, v in [('dept', dept), ('lead', lead), ('real', real), ('age', age),
                      ('prev', prev), ('edu', edu), ('school', school), ('status', status)]:
            locals()[k]  # just reference

        def clean(v):
            return '' if v in ('nan', 'None', 'NaN') else v

        rows.append({
            'name': name,
            'real_name': clean(real),
            'join_date': join_date,
            'dept': clean(dept),
            'lead': clean(lead),
            'status': clean(status),
            'age': clean(age),
            'prev_company': clean(prev),
            'education': clean(edu),
            'school': clean(school),
        })
    return rows

def months_diff(d1, d2):
    """d1 到 d2 相差月数（浮点）"""
    return (d2 - d1).days / 30.44

def assign_reviews(new_hires, review_months, today):
    """
    按入职日期将新人分配到各期述职：
    - 以今天为基准，每2个月一期（可按实际需求调整）
    - 满 review_months 个月才纳入最近一期
    返回 list of dicts: { 'session': N, 'date': date, 'members': [...] }
    """
    if not new_hires:
        return []
    
    # 以今天为基准，找最早入职时间
    min_join = min(p['join_date'] for p in new_hires)
    
    # 生成述职期次：每2个月一个述职日（约定为每月最后一个月的第X日，这里简化为2月间隔）
    sessions = []
    # 第一期基准：min_join + review_months
    session_date = min_join + timedelta(days=int(review_months * 30.44))
    # 对齐到最近的月底/月初
    # 简化：直接用计算日期，让调用方知道可自定义
    
    sess_idx = 1
    remaining = list(new_hires)
    
    while remaining:
        members = [p for p in remaining if months_diff(p['join_date'], session_date) >= review_months]
        # 按入职日期排序
        members.sort(key=lambda x: x['join_date'])
        if members:
            sessions.append({'session': sess_idx, 'date': session_date, 'members': members})
            remaining = [p for p in remaining if p not in members]
            sess_idx += 1
        session_date = date(session_date.year + (session_date.month // 12),
                           (session_date.month % 12) + 1, 1) + timedelta(days=60)
        # 防死循环
        if sess_idx > 20:
            break
    
    # 剩余人员（未来才到时间）归入最后一期
    if remaining:
        sessions.append({'session': sess_idx, 'date': session_date, 'members': remaining})
    
    return sessions

def build_name_display(p):
    """薯名(真实姓名) 格式"""
    if p['real_name']:
        return f"{p['name']}({p['real_name']})"
    return p['name']

def status_badge(status):
    if '试' in status or 'trial' in status.lower():
        return '<span class="badge bb">试用期</span>'
    if '转正' in status or '正式' in status:
        return '<span class="badge bg">已转正</span>'
    if '离' in status:
        return '<span class="badge br">待离职</span>'
    return f'<span class="badge by">{status}</span>'

def build_html(args, all_employees, new_hires, sessions, today):
    dept_name = args.dept or "团队"
    fixed_reviewers = [r.strip() for r in args.reviewer.split(',') if r.strip()] if args.reviewer else []
    
    # KPI
    total = len(all_employees)
    trial_count = sum(1 for p in new_hires if '试' in p['status'] or not p['status'])
    passed_count = sum(1 for p in new_hires if '转正' in p['status'] or '正式' in p['status'])
    leaving_count = sum(1 for p in new_hires if '离' in p['status'])
    
    # 部门列表
    depts = sorted(set(p['dept'] for p in new_hires if p['dept']))
    dept_btns = '\n'.join(
        f'<button class="dept-btn" onclick="filterDept(this,\'{d}\')">{d}</button>'
        for d in depts
    )
    
    # 新人名单行
    roster_rows = ''
    for p in sorted(new_hires, key=lambda x: x['join_date']):
        roster_rows += f'''
      <tr data-dept="{p['dept']}">
        <td>{build_name_display(p)}</td>
        <td>{status_badge(p['status'])}</td>
        <td>{p['dept']}</td>
        <td>{p['lead']}</td>
        <td>{p['join_date'].strftime('%Y/%m/%d')}</td>
        <td>{p['age']}</td>
        <td>{p['prev_company']}</td>
        <td>{p['education']}</td>
        <td>{p['school']}</td>
      </tr>'''

    # 述职期次卡片
    sessions_html = ''
    for sess in sessions:
        members = sess['members']
        sess_date = sess['date']
        sess_label = f"第{sess['session']}期述职 · {sess_date.strftime('%Y年%-m月%-d日')}"
        
        # 评委列：固定评委 + 各成员直属上级（去重）
        leads = list(dict.fromkeys([p['lead'] for p in members if p['lead']]))
        all_reviewers = fixed_reviewers + [l for l in leads if l not in fixed_reviewers]
        
        # 表头
        reviewer_ths = ''.join(
            f'<th style="padding:8px 10px;text-align:left;border-bottom:2px solid #e5e7eb;white-space:nowrap;font-size:12px;font-weight:600;color:#374151">{r}</th>'
            for r in all_reviewers
        )
        reviewer_ths += '<th style="padding:8px 10px;text-align:left;border-bottom:2px solid #e5e7eb;white-space:nowrap;font-size:12px;font-weight:600;color:#dc2626">综合</th>'
        
        # 每人一行
        member_rows = ''
        for i, p in enumerate(members):
            is_last = (i == len(members) - 1)
            border = '' if is_last else 'border-bottom:1px solid #f3f4f6;'
            
            score_cells = ''
            for _ in all_reviewers:
                score_cells += f'''<td style="padding:8px 10px;{border}min-width:90px">
  <div contenteditable="true" style="font-weight:700;font-size:14px;min-height:20px;outline:none;border-radius:3px;cursor:text" 
    onmouseover="this.style.background='#f9fafb'" 
    onmouseout="if(document.activeElement!==this)this.style.background=''"
    onfocus="this.style.background='#fffbeb';this.style.boxShadow='0 0 0 2px #fcd34d'" 
    onblur="this.style.background='';this.style.boxShadow=''"></div>
  <div contenteditable="true" style="font-size:12px;color:#6b7280;margin-top:2px;min-height:16px;outline:none;border-radius:3px;cursor:text"
    onmouseover="this.style.background='#f9fafb'" 
    onmouseout="if(document.activeElement!==this)this.style.background=''"
    onfocus="this.style.background='#fffbeb';this.style.boxShadow='0 0 0 2px #fcd34d'" 
    onblur="this.style.background='';this.style.boxShadow=''">评语</div>
</td>'''
            # 综合列
            score_cells += f'''<td style="padding:8px 10px;{border}background:#fff7ed">
  <div contenteditable="true" style="font-weight:700;font-size:15px;min-height:20px;outline:none;border-radius:3px;cursor:text;color:#c2410c"
    onmouseover="this.style.background='#ffedd5'" 
    onmouseout="if(document.activeElement!==this)this.style.background=''"
    onfocus="this.style.background='#fffbeb';this.style.boxShadow='0 0 0 2px #fcd34d'" 
    onblur="this.style.background='';this.style.boxShadow=''"></div>
</td>'''
            
            doc_cell_onblur = "var t=this.innerText.trim();if(t&&t.startsWith('http')){this.innerHTML='<a href=\"'+t+'\" target=\"_blank\" style=\"color:#7c3aed;text-decoration:none;font-size:12px\">📎 查看文档</a>';}"
            member_rows += (
                f'<tr>'
                f'<td style="padding:8px 10px;{border}font-weight:700">{build_name_display(p)}</td>'
                f'<td style="padding:8px 10px;{border}">{p["dept"]}</td>'
                f'<td style="padding:8px 10px;{border}">{p["lead"]}</td>'
                f'<td style="padding:8px 10px;{border}">{p["join_date"].strftime("%Y/%m/%d")}</td>'
                f'<td style="padding:8px 10px;{border}">'
                f'<div contenteditable="true" '
                f'style="font-size:12px;color:#7c3aed;min-height:20px;outline:none;border-radius:3px;cursor:text;word-break:break-all"'
                f' onmouseover="this.style.background=\'#f5f3ff\'"'
                f' onmouseout="if(document.activeElement!==this)this.style.background=\'\'"'
                f' onfocus="this.style.background=\'#f5f3ff\';this.style.boxShadow=\'0 0 0 2px #a78bfa\'"'
                f' onblur="this.style.background=\'\';this.style.boxShadow=\'\';{doc_cell_onblur}"'
                f' placeholder="粘贴文档链接"></div>'
                f'</td>'
                f'{score_cells}'
                f'</tr>'
            )
        
        reviewer_label = '、'.join(all_reviewers) if all_reviewers else '待定'
        member_count = len(members)
        
        sessions_html += f'''
<div style="background:#fff;border-radius:12px;padding:20px;margin-top:16px;box-shadow:0 1px 4px rgba(0,0,0,.06)">
  <div style="font-size:15px;font-weight:700;color:#111827;margin-bottom:4px">🎓 {sess_label}</div>
  <div style="font-size:13px;color:#6b7280;margin-bottom:12px">
    基准日 {sess_date.strftime('%Y/%m/%d')} · 入职{args.review_months}月以上 · 共{member_count}人
    {f" &nbsp;|&nbsp; 评委：{reviewer_label}" if all_reviewers else ""}
  </div>
  <div style="overflow-x:auto">
  <table style="width:100%;border-collapse:collapse;font-size:13px;min-width:700px">
    <thead>
      <tr style="background:#f9fafb">
        <th style="padding:8px 10px;text-align:left;border-bottom:2px solid #e5e7eb;white-space:nowrap;font-size:12px;font-weight:600;color:#374151">薯名</th>
        <th style="padding:8px 10px;text-align:left;border-bottom:2px solid #e5e7eb;white-space:nowrap;font-size:12px;font-weight:600;color:#374151">小组</th>
        <th style="padding:8px 10px;text-align:left;border-bottom:2px solid #e5e7eb;white-space:nowrap;font-size:12px;font-weight:600;color:#374151">L1（直属）</th>
        <th style="padding:8px 10px;text-align:left;border-bottom:2px solid #e5e7eb;white-space:nowrap;font-size:12px;font-weight:600;color:#374151">入职日期</th>
        <th style="padding:8px 10px;text-align:left;border-bottom:2px solid #e5e7eb;white-space:nowrap;font-size:12px;font-weight:600;color:#374151">述职文档</th>
        {reviewer_ths}
      </tr>
    </thead>
    <tbody>
      {member_rows}
    </tbody>
  </table>
  </div>
  <div contenteditable="true" style="margin-top:12px;font-size:12px;color:#888;border-top:1px solid #f0f0f0;padding-top:10px;outline:none;border-radius:4px;cursor:text;"
    onmouseover="this.style.background='#fffbeb'" 
    onmouseout="if(document.activeElement!==this)this.style.background=''"
    onfocus="this.style.background='#fffbeb';this.style.boxShadow='0 0 0 2px #fcd34d'" 
    onblur="this.style.background='';this.style.boxShadow=''">
    ⚠️ 延期述职：（暂无）
  </div>
</div>'''

    # 密码保护
    pw_overlay = ''
    if args.password:
        pw = args.password.replace("'", "\\'")
        pw_overlay = f'''<div id="pw-overlay" style="position:fixed;inset:0;background:rgba(17,24,39,0.97);z-index:99999;display:flex;align-items:center;justify-content:center;">
  <div style="background:#fff;border-radius:16px;padding:40px 36px;width:340px;text-align:center;box-shadow:0 20px 60px rgba(0,0,0,.4);">
    <div style="font-size:36px;margin-bottom:12px;">🔒</div>
    <h2 style="font-size:18px;font-weight:700;color:#111827;margin-bottom:6px;">{dept_name}新人看板</h2>
    <p style="font-size:13px;color:#6b7280;margin-bottom:24px;">请输入访问密码</p>
    <input id="pw-input" type="password" placeholder="请输入密码" 
      style="width:100%;padding:10px 14px;border:2px solid #e5e7eb;border-radius:8px;font-size:15px;outline:none;box-sizing:border-box;"
      onkeydown="if(event.key==='Enter')checkPw()">
    <button onclick="checkPw()" style="margin-top:12px;width:100%;padding:11px;background:#ff2442;color:#fff;border:none;border-radius:8px;font-size:15px;font-weight:600;cursor:pointer;">进入看板</button>
    <div id="pw-err" style="margin-top:10px;font-size:12px;color:#ef4444;min-height:18px;"></div>
  </div>
</div>
<script>
(function(){{
  if(sessionStorage.getItem('pw_ok')==='1'){{document.getElementById('pw-overlay').style.display='none';return;}}
  document.getElementById('pw-input').focus();
}})();
function checkPw(){{
  if(document.getElementById('pw-input').value==='{pw}'){{
    sessionStorage.setItem('pw_ok','1');
    document.getElementById('pw-overlay').style.display='none';
  }}else{{
    var e=document.getElementById('pw-err');
    e.textContent='密码错误，请重试';
    document.getElementById('pw-input').value='';
    setTimeout(function(){{e.textContent='';}},2000);
  }}
}}
</script>'''

    # 完整 HTML
    html = f'''<!DOCTYPE html>
<html lang="zh">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>{dept_name} · 新人 Landing 看板</title>
<style>
:root{{--red:#ff2442;--dark:#1a1a2e;--border:#e8e8e8;--gray:#888;--bg:#f5f5f7;--card:#fff}}
*{{box-sizing:border-box;margin:0;padding:0}}
body{{font-family:'PingFang SC',system-ui,sans-serif;background:var(--bg);color:#222;min-height:100vh}}
.header{{background:var(--dark);color:#fff;padding:18px 24px}}
.header h1{{font-size:18px;font-weight:700}}
.header .sub{{font-size:12px;opacity:.6;margin-top:4px}}
.section-title{{font-size:15px;font-weight:700;color:var(--dark);margin:20px 0 12px;padding-left:10px;border-left:3px solid var(--red)}}
.kpi-row{{display:flex;gap:12px;flex-wrap:wrap;margin-bottom:20px}}
.kpi-card{{background:var(--card);border-radius:12px;padding:16px 20px;flex:1;min-width:120px;box-shadow:0 1px 4px rgba(0,0,0,.07)}}
.kpi-value{{font-size:26px;font-weight:700;color:var(--red)}}
.kpi-label{{font-size:12px;color:var(--gray);margin-top:4px}}
.filter-bar{{background:#fff;border-radius:12px;padding:12px 16px;margin-bottom:16px;display:flex;align-items:center;gap:8px;flex-wrap:wrap;box-shadow:0 1px 4px rgba(0,0,0,.07)}}
.filter-bar label{{font-size:13px;color:var(--gray);font-weight:500;white-space:nowrap}}
.dept-btn{{border:1.5px solid var(--border);background:#fff;border-radius:20px;padding:5px 13px;font-size:12px;cursor:pointer;transition:all .15s;color:#333}}
.dept-btn:hover{{border-color:var(--red);color:var(--red)}}
.dept-btn.active{{background:var(--red);color:#fff;border-color:var(--red);font-weight:600}}
.chart-card{{background:var(--card);border-radius:12px;padding:16px;box-shadow:0 1px 4px rgba(0,0,0,.07);margin-bottom:16px}}
table.dt{{width:100%;border-collapse:collapse;font-size:13px}}
table.dt th{{background:#f8f8f8;padding:8px 10px;text-align:left;font-weight:600;border-bottom:2px solid var(--border);white-space:nowrap}}
table.dt td{{padding:8px 10px;border-bottom:1px solid #f0f0f0}}
table.dt tr:hover td{{background:#fafafa}}
.badge{{display:inline-block;padding:2px 8px;border-radius:10px;font-size:11px;font-weight:600}}
.bg{{background:#dcfce7;color:#16a34a}}.bb{{background:#dbeafe;color:#2563eb}}
.by{{background:#fef9c3;color:#b45309}}.br{{background:#fee2e2;color:#ef4444}}
.panel{{padding:20px 20px 40px}}
</style>
</head>
<body>
{pw_overlay}
<div class="header">
  <h1>🌱 {dept_name} · 新人 Landing 看板</h1>
  <div class="sub">生成日期：{today.strftime('%Y-%m-%d')} · 新人范围：入职≤1年 · 共 {len(new_hires)} 人</div>
</div>

<div class="panel">
  <!-- KPI -->
  <div class="section-title">📊 新人 Landing 概览</div>
  <div class="kpi-row">
    <div class="kpi-card"><div class="kpi-value">{total}</div><div class="kpi-label">在职总人数</div></div>
    <div class="kpi-card"><div class="kpi-value">{len(new_hires)}</div><div class="kpi-label">新人人数（≤1年）</div></div>
    <div class="kpi-card"><div class="kpi-value">{round(len(new_hires)/total*100) if total else 0}%</div><div class="kpi-label">新人占比</div></div>
    <div class="kpi-card"><div class="kpi-value">{trial_count}</div><div class="kpi-label">试用期中</div></div>
    <div class="kpi-card"><div class="kpi-value">{passed_count}</div><div class="kpi-label">已转正</div></div>
  </div>

  <!-- 新人名单 -->
  <div class="section-title">📋 新人名单</div>
  <div class="filter-bar">
    <label>小组：</label>
    <button class="dept-btn active" onclick="filterDept(this,'全部')">全部</button>
    {dept_btns}
  </div>
  <div class="chart-card" style="padding:12px 16px">
    <div style="font-size:12px;color:#888;margin-bottom:10px">
      试用期中 <strong>{trial_count}</strong> 人 · 已转正 <strong>{passed_count}</strong> 人 · 待离职 <strong>{leaving_count}</strong> 人
    </div>
    <div style="overflow-x:auto">
    <table class="dt" id="roster-table" style="min-width:800px">
      <tr>
        <th>薯名</th><th>状态</th><th>部门/小组</th><th>直接上级</th>
        <th>入职日期</th><th>年龄</th><th>前公司</th><th>学历</th><th>学校</th>
      </tr>
      {roster_rows}
    </table>
    </div>
  </div>

  <!-- 新人 GD 项目说明 -->
  <div class="section-title">🎓 新人 GD 述职项目</div>
  <div class="chart-card" style="padding:16px 20px;margin-bottom:16px">
    <div id="gd-bg" style="font-size:13px;line-height:1.9;color:#444">
      <p>为帮助新人更好地融入团队、展示试用期成果，特设立 <strong>新人 GD（Graduate Defense）述职项目</strong>。</p>
      <p style="margin-top:8px">每人 10 分钟陈述 + 10 分钟 Q&A，评委由各 L1 担任。述职内容涵盖：个人背景、试用期独立完成的工作成果、对团队的贡献，以及对未来的展望。</p>
      <p style="margin-top:8px">述职评分维度参考转正标准，综合评委打分给出最终结果。</p>
    </div>
  </div>

  <!-- 各期述职看板 -->
  {sessions_html}
</div>

<script>
function filterDept(btn, dept) {{
  document.querySelectorAll('.dept-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  document.querySelectorAll('#roster-table tr[data-dept]').forEach(function(tr) {{
    tr.style.display = (dept === '全部' || tr.dataset.dept === dept) ? '' : 'none';
  }});
}}
</script>
</body>
</html>'''
    return html

def main():
    args = parse_args()
    today = date.today()
    
    # 加载花名册
    print(f"📂 加载花名册：{args.roster}")
    df = load_roster(args.roster)
    print(f"   检测到 {len(df)} 行，{len(df.columns)} 列")
    
    # 提取字段
    employees = extract_fields(df)
    print(f"   有效员工记录：{len(employees)} 人")
    
    # 筛选新人（在职 + 入职 ≤ 1 年）
    cutoff = today - timedelta(days=365)
    new_hires = [
        p for p in employees
        if p['join_date'] >= cutoff and '离' not in p['status']
    ]
    new_hires.sort(key=lambda x: x['join_date'])
    print(f"   新人（入职≤1年，在职）：{len(new_hires)} 人")
    
    # 分配述职期次
    sessions = assign_reviews(new_hires, args.review_months, today)
    print(f"   共生成 {len(sessions)} 期述职")
    for s in sessions:
        print(f"   第{s['session']}期：{s['date'].strftime('%Y-%m-%d')} · {len(s['members'])} 人")
    
    # 生成 HTML
    html = build_html(args, employees, new_hires, sessions, today)
    
    out = Path(args.output)
    out.write_text(html, encoding='utf-8')
    print(f"\n✅ 已生成：{out.resolve()}")
    print(f"   文件大小：{out.stat().st_size // 1024} KB")

if __name__ == '__main__':
    main()
