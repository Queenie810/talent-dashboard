---
name: new-hire-landing
description: 新人 Landing 述职看板生成器。HRBP 将花名册（Excel/CSV）发给助手，自动读取全量数据，筛选试用期新人，按入职时间分配述职期次，生成完整的交互式 HTML 看板（含新人名单 + 各期述职评分表）。触发词：生成新人 Landing 看板、新人述职看板、帮我做 GD 看板、花名册生成新人看板、试用期名单。
---

# New Hire Landing — 新人述职看板生成器

## 工作流程

1. 用户发送花名册文件（xlsx / xls / csv）
2. 询问以下配置（如用户未提供）：
   - **部门/团队名称**（用于标题）
   - **固定评委**（薯名，逗号分隔；如"又思,金槌"）
   - **述职资格门槛**（入职满几个月，默认 5.5 个月）
   - **看板密码**（可选，留空跳过）
3. 将文件保存到工作区（`/home/node/.openclaw/workspace/` 下），运行生成脚本
4. 输出 HTML 文件，提供本地预览地址或部署建议

## 核心脚本

```bash
python3 scripts/generate_landing.py \
  <花名册路径> \
  --dept "<部门名称>" \
  --reviewer "<又思,金槌>" \
  --review-months 5.5 \
  --password "<访问密码>" \
  --output <输出路径.html>
```

脚本依赖：`pandas`、`openpyxl`（xlsx）、`xlrd`（xls）。安装命令：
```bash
pip install pandas openpyxl xlrd
```

## 列名识别

花名册列名使用模糊匹配，详见 `references/roster-columns.md`。

**必须包含**：薯名/姓名 + 入职日期  
**推荐包含**：部门/小组、直接上级、在职状态

## 述职分期规则

- **新人范围**：今天往前 365 天内入职的在职员工
- **分期**：入职满 N 个月（默认 5.5）才纳入该期，每 2 个月一期
- **评委列**：`--reviewer` 固定评委 + 各成员直属上级（自动去重合并）

## 生成的 HTML 功能

- **KPI 卡片**：总人数、新人数、试用期/转正/待离职统计
- **部门筛选**：按小组过滤新人名单
- **新人名单表**：薯名、状态 badge、部门、直属上级、入职日期、年龄、前公司、学历、学校
- **GD 项目说明**：可编辑的项目背景文字
- **各期述职表**：每人一行，评委打分 + 评语可直接在浏览器中填写（contenteditable）
- **密码保护**（可选）：sessionStorage 验证

## 常见情况处理

- **多个 sheet**：脚本默认读取第一个 sheet；如需指定，读 `references/roster-columns.md` 后手动传参
- **日期识别失败**：检查列名是否包含"入职"关键词，日期格式是否规范
- **述职人数分期不合理**：调整 `--review-months` 参数，或在生成后手动调整
- **需要部署到外网**：HTML 为单文件，可直接用 surge.sh 部署（参考 MEMORY.md 中的部署方式）
